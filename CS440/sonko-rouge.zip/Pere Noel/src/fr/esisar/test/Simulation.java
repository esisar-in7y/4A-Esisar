package fr.esisar.test;

import fr.esisar.lutin.LutinChef;
import fr.esisar.lutin.LutinManager;
import fr.esisar.lutin.LutinOuvrier;
import fr.esisar.perenoel.ConcreteObserver;
import fr.esisar.perenoel.ConcreteSubject;
import fr.esisar.perenoel.Mail;
import fr.esisar.perenoel.MailBox;

public class Simulation {

	public Simulation() {
	}

	public static void main(String[] args) {
		Simulation s1 = new Simulation();
		s1.execute();
	}

	private void execute() {
		
		MailBox mailbox = new MailBox();
		
		ConcreteSubject noel = new ConcreteSubject();
		ConcreteObserver perenoel = new ConcreteObserver(noel);
		noel.attach(perenoel);
		
		Mail m1 = new Mail(noel, "Je voudrais bien des cadeaux stp.", 2);

		System.out.println(perenoel.newmail());
		mailbox.receive_mail(m1);
		System.out.println(perenoel.newmail());
		
		LutinChef chef = new LutinChef("Chef",0,noel,mailbox);
		LutinManager manager1 = new LutinManager("Manager 1",1);
		manager1.addEmploye(new LutinOuvrier("Ouvrier 1",2));
		LutinManager manager3 = new LutinManager("Manager 3",2);
		manager3.addEmploye(new LutinOuvrier("Ouvrier 2",3));
		manager3.addEmploye(new LutinOuvrier("Ouvrier 3",3));
		manager1.addEmploye(manager3);
		chef.addEmploye(manager1);
		chef.addEmploye(new LutinOuvrier("Ouvrier 5",1));
		LutinManager manager2 = new LutinManager("Manager 2",1);
		manager2.addEmploye(new LutinOuvrier("Ouvrier 4",2));
		chef.addEmploye(manager2);
		
		chef.afficherHierarchie();
		
		chef.LireCourier();
		
	}

}
