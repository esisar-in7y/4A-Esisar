package fr.esisar.lutin;

import java.util.ArrayList;
import java.util.List;

public class LutinManager extends Lutin {

	List<Lutin> lutins;
	
	public LutinManager(String nom, int niveau) {
		super(nom, niveau);
		lutins = new ArrayList<Lutin>();
	}

	public void addEmploye(Lutin lutin) {
		lutins.add(lutin);
	}
	
	public void removeEmploye(Lutin lutin) {
		lutins.remove(lutin);
	}
	
	@Override
	public void afficherHierarchie() {
		System.out.print(new String(new char[niveau]).replace("\0", "   "));
		System.out.println("++ "+this.toString());
		for (Lutin lutin : lutins) {
			lutin.afficherHierarchie();
		}
	}
	
	@Override
	protected void distribuer_cadeau(int nb_cadeaux) {
		int L = lutins.size();
		int nb = nb_cadeaux/L;
		for(Lutin lutin : lutins) {
			lutin.distribuer_cadeau(nb);
		}
		lutins.get(0).distribuer_cadeau(nb_cadeaux%L); // Le reste
	}

}
