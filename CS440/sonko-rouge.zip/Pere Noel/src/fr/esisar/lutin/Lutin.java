package fr.esisar.lutin;

import fr.esisar.perenoel.ConcreteObserver;
import fr.esisar.perenoel.ConcreteSubject;

public abstract class Lutin extends ConcreteObserver {

	String nom;
	int niveau;
	
	public Lutin(String nom, int niveau) {
		super(null);
		this.nom = nom;
		this.niveau = niveau;
	}
	
	public Lutin(String nom, int niveau, ConcreteSubject subject) {
		super(subject);
		this.nom = nom;
		this.niveau = niveau;
	}
	
	public abstract void afficherHierarchie();
	
	protected abstract void distribuer_cadeau(int nb_cadeaux);

	@Override
	public String toString() {
		return "Lutin [nom=" + nom + ", niveau=" + niveau + "]";
	} 

}
