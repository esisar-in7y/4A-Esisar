package fr.esisar.lutin;

public class LutinOuvrier extends Lutin {

	public LutinOuvrier(String nom, int niveau) {
		super(nom, niveau);
	}

	int nb_cadeaux=0;
	
	@Override
	public void afficherHierarchie() {
		System.out.print(new String(new char[niveau]).replace("\0", "   "));
		System.out.println("-- "+this.toString());
	}

	public void ajouter_cadeaux(int nb_cadeaux) {
		this.nb_cadeaux += nb_cadeaux;
	}

	@Override
	protected void distribuer_cadeau(int nb_cadeaux) {
		ajouter_cadeaux(nb_cadeaux);
	}
	
}
