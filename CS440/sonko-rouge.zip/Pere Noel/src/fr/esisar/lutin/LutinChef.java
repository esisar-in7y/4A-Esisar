package fr.esisar.lutin;

import fr.esisar.perenoel.ConcreteSubject;
import fr.esisar.perenoel.Mail;
import fr.esisar.perenoel.MailBox;

public class LutinChef extends LutinManager {
	
	public LutinChef(String nom, int niveau, ConcreteSubject subject, MailBox mailbox) {
		super(nom, niveau);
		this.mailbox = mailbox;
		current_index = 0;
	}

	MailBox mailbox;
	int current_index;
	
	public void LireCourier() {
		for(int i=current_index; i<mailbox.get_nbMails(); i++) {
			Mail mail = mailbox.get_mail(i);
			distribuer_cadeau(mail.getNb_cadeaux());
		}
	}

	@Override
	protected void update() {
		observerState = subject.getState();
		LireCourier();
	}
	
}
