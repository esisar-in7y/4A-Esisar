package fr.esisar.perenoel;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import fr.esisar.perenoel.ConcreteSubject.State;

public class MailBox {

	List<Mail> mails;
	
	public MailBox() {
		mails = new ArrayList<Mail>();
	}

	public void receive_mail(Mail mail) {
		mails.add(mail);
		mail.set_reception_time( LocalDateTime.now() );
		mail.getSubject().setState(State.NEW_MAIL);
		mail.getSubject().notification();
	}
	
	public Mail get_mail(int i) {
		return mails.get(i);
	}
	
	public int get_nbMails() {
		return mails.size();
	}
}
