package fr.esisar.perenoel;

import fr.esisar.perenoel.ConcreteSubject.State;

public class ConcreteObserver extends Observer {


	public ConcreteObserver(ConcreteSubject subject) {
		super();
		this.subject = subject;
		observerState = State.RIEN;
	}

	protected State observerState;
	protected ConcreteSubject subject;

	protected void update() {
		observerState = subject.getState();
	}
	
	public boolean newmail() {
		return observerState == State.NEW_MAIL;		
	}
	
}
