package fr.esisar.perenoel;

public abstract class Observer {

	public Observer() {
		
	}

	protected abstract void update();

}
