package fr.esisar.perenoel;


public class ConcreteSubject extends Subject {
	
	public enum State { NEW_MAIL, RIEN };
	State subjectState;
	
	public ConcreteSubject() {
		
	}

	public void setState(State state) {
		subjectState = state;
	}
	
	public State getState() {
		return subjectState;
	}

}
