package fr.esisar.perenoel;

import java.time.LocalDateTime;

public class Mail {

	private ConcreteSubject subject;
	private String contenu;
	private int nb_cadeaux;
	private LocalDateTime date_reception;
	
	public Mail(ConcreteSubject subject, String contenu, int nb_cadeaux) {
		super();
		this.subject = subject;
		this.contenu = contenu;
		this.nb_cadeaux = nb_cadeaux;
	}

	public void set_reception_time(LocalDateTime date) {
		date_reception = date;
	}

	public ConcreteSubject getSubject() {
		return subject;
	}

	public String getContenu() {
		return contenu;
	}

	public int getNb_cadeaux() {
		return nb_cadeaux;
	}

	public LocalDateTime getDate_reception() {
		return date_reception;
	}

}
