package fr.esisar.tp4;

public class EntrepriseTestDrive {

	public static void main(String[] args) {
		HierarchieTest runner = new HierarchieTest();
		runner.createHierarchie();
	}

}
