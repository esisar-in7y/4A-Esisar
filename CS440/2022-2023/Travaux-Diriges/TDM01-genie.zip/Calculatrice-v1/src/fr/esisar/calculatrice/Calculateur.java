/**
 * 
 */
package fr.esisar.calculatrice;

/**
 * @author userir
 *
 */
public class Calculateur {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculatrice c = new Calculatrice();
		System.out.println(c.ajouter(1,1));
		System.out.println(c.soustraire(1,1));
		System.out.println(c.multiplier(1,1));
		System.out.println(c.diviser(1,1));
	}

}
