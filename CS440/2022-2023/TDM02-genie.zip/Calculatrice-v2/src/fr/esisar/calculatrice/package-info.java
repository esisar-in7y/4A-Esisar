/**
 * 
 */
/**
 * @author userir
 *
 */
package fr.esisar.calculatrice;