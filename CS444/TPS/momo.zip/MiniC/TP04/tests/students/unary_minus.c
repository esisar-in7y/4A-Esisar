#include "printlib.h"

int main() {
    
    int x, y;
    x = 33;
    y = -66;
    println_int(x+y);
    println_int(-y);
	
    return 0;
}

// EXPECTED
// -33
// 66
