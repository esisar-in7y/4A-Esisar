#include "printlib.h"

int main() {
    
    int x,y;
    x=3;
    if (x<5) {
    y=x+1;
    }
    return 0;
}

// EXPECTED