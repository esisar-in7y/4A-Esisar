int main() {
    string b;
	return 0;
}

// SKIP TEST EXPECTED
// EXITCODE 5
// EXPECTED
// Unsupported type string