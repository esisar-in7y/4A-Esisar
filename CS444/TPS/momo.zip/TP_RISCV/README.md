# Instructions pour installer les outils riscv pour le TP de compilation
# CS444 @ Esisar, 2022-23

Suivre les instructions données à :

https://matthieu-moy.fr/spip/?Pre-compiled-RISC-V-GNU-toolchain-and-spike&lang=fr

