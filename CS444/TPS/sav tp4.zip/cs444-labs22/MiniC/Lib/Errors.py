class MiniCRuntimeError(Exception):
    pass


class MiniCInternalError(Exception):
    pass


class MiniCUnsupportedError(Exception):
    pass


class MiniCTypeError(Exception):
    pass


class AllocationError(Exception):
    pass
