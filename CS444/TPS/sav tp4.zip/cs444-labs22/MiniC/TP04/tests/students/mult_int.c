#include "printlib.h"

int main() {
    
    int a,b;
	a=10;
	b=5;
    println_int(a*b);
    println_int(0*a);
    println_int(b*1);
	
    return 0;
}

// EXPECTED
// 50
// 0
// 5