#include "printlib.h"

int main() {
    
    int a,b;
	a=2;
	b=3;
    println_bool(a <= a);
    println_bool(a <= b);
    println_bool(b <= a);
    println_bool(a >= a);
    println_bool(a >= b);
    println_bool(b >= a);
    return 0;
}

// EXPECTED
// 1
// 1
// 0
// 1
// 0
// 1