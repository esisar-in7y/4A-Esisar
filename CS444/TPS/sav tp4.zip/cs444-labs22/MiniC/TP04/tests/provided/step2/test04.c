#include "printlib.h"

int main() {
    
    int n;
    bool a,b;
    n=1;
    a=true;
    b=(a==(n<6));
    return 0;
}

// EXPECTED