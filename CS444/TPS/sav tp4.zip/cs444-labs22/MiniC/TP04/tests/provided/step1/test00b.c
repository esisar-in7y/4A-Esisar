#include "printlib.h"

int main() {
    
    int x,y;
    x=4;
    y=12+x;
    return 0;
}

// EXPECTED