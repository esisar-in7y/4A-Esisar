#include "printlib.h"

int main() {
    
    int n;
    n=6;
    
    return 0;
}

// EXPECTED