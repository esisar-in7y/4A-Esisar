# Bonus for TP1

Create a file `Slide18.g4` with the grammar used in the course on descendant syntactic analysis (slide 18).  Add a `start` rule as axiom:

```ANTLR4
grammar Slide18;

start : expr EOF;
```


Generate the Python code of the analyser with:

```
antlr4 -Dlanguage=Python3 Slide18.g4
```


The generated file `Slide18Parser.py` file is a recursive descent parser
similar to the one studied in the course (slides 24-26).  Look at the
code of the methods corresponding to each non terminal symbol to get
convinced.

You can also generate the same analyser as a java program with:
```
antlr4 -no-listener Slide18.g4
```


In file `Slide18Parser.java`, look especially at the `public final`
methods.

Antlr provides a `grun` command to try a java parser.  First compile
the java files:

```
javac Slide18*.java
```


then run `grun` to test the lexer and display the lexical units:

```
grun Slide18 tokens -tokens
```


You can also try the parser and look at the tree

```
grun Slide18 start -tree
```


And even see it displayed graphically!

```
grun Slide18 start -gui
```
