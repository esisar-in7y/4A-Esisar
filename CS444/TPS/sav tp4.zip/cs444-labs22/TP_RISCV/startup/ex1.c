/*Source code from Laure Gonnord, CAP Lab 1*/

#include <stdio.h>

int main(){

  int x = 41;
  x = x+1;
  printf("%d\n",x);
  
  return 0;
}
