#include "printlib.h"

int main(){
  println_int(42);
  return 0;
}
  
// EXPECTED
// 42
