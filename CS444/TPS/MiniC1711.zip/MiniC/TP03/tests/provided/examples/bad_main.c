#include "printlib.h"

int toto(){
  println_int(42);
  return 0;
}

// EXITCODE 1
// EXPECTED
// No main function in file

