#include "printlib.h"

int main(){
  int x,y;
  int z,x;
  x=42;
  return 0;
}

// EXITCODE 2
// EXPECTED
// In function main: Line 5 col 2: Variable x already declared
