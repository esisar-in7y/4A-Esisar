#include "printlib.h"

int main()
{

    int x, y;
    x = 2;
    if (x < 4)
        x = 4;
    else
        x = 5;

    return 0;
}

// EXPECTED