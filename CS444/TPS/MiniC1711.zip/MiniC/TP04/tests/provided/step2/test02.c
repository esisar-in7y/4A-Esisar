#include "printlib.h"

int main() {
    
    int x,y;
    
    x = 9;
    if (x < 2)
    y=7;
    else
    y=12;
    x = y;
    return 0;
}

// EXPECTED