#include "printlib.h"

int main() {
    
    println_bool(3 >= 2);
    return 0;
}

// EXPECTED
// 1
