#include "printlib.h"

int main() {
    
    int x,y,z;
    x=2;
    if (x<3) {
    y=7;
    } else {
    y=8;
    }
    z=y+1;
    return 0;
}

// EXPECTED