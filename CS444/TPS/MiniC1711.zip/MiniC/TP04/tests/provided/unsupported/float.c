int main() {
    float f;
	return 0;
}

// SKIP TEST EXPECTED
// EXITCODE 5
// EXPECTED
// Unsupported type float