#include "printlib.h"

int main() {
    
    int x,y,z,u;
    x=3;
    if (x < 4) {
    z=4;
    }
    else if ( x < 5) {
    z=5;
    }
    else {
    z=6 ;
    }
    u=z+1;
    return 0;
}

// EXPECTED