#include "printlib.h"

int main()
{
    int x;
    x = 0;
    while (x < 4)
    {
        x = x + 1;
    }
    return 0;
}

// EXPECTED