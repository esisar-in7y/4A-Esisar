#include "printlib.h"

int main() {
    
    int n,u;
    n=6;
    println_int(n);
    
    return 0;
}

// EXPECTED
// 6