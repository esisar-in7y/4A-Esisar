#include "printlib.h"

int main() {
    
    int n,u,v;
    n=6;
    u=12;
    v=n+u;
    println_int(v);
    
    return 0;
}

// EXPECTED
// 18