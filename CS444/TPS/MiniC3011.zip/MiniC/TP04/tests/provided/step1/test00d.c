#include "printlib.h"

int main() {
    
    int a,n;
    n=1;
    a=n+12;
    return 0;
}

// EXPECTED