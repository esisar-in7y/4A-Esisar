int main() {
    println_string("Hello");
	return 0;
}

// SKIP TEST EXPECTED
// EXITCODE 5
// EXPECTED
// Unsupported type string