int main() {
    println_float(0.0);
	return 0;
}

// SKIP TEST EXPECTED
// EXITCODE 5
// EXPECTED
// Unsupported type float
