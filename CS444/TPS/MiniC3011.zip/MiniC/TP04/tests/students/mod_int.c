#include "printlib.h"

int main() {
    
    int a,b;
	a=10;
	b=5;
    println_int(a%b);
    println_int(b%3);
    println_int(3%b);
	
    return 0;
}

// EXPECTED
// 0
// 2
// 3