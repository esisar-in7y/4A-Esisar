#include "printlib.h"

int main() {
    
    bool t,f;
	t = true;
    println_bool(!t);
    println_bool(!f);
    println_bool(!!!f);
    return 0;
}

// EXPECTED
// 0
// 1
// 1