#include "printlib.h"

int main(){
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,aa,bb,cc,dd,ee,ff,gg,hh,ii,jj,kk,ll,mm,nn;
	println_int(a);
	return 0;
}
// EXPECTED
// 0