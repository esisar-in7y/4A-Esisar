#include "printlib.h"

int main() {
    
    bool t,f;
	t = true;
    println_bool(t && t);
    println_bool(t && f);
    println_bool(f && t);
    println_bool(f && f);
    return 0;
}

// EXPECTED
// 1
// 0
// 0
// 0