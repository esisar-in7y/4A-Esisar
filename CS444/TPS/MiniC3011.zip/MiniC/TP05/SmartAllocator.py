from Lib.Operands import Temporary, Operand, S, Register, DataLocation, GP_REGS, Offset
from Lib.Statement import Instruction
from Lib.Allocator import Allocator
from Lib import RiscV
from Lib.Graphes import Graph  # For Graph coloring utility functions
from Lib.Errors import MiniCInternalError
from typing import List, Dict


class SmartAllocator(Allocator):
    _igraph: Graph  # interference graph

    def __init__(self, fdata, basename, liveness, debug=False, debug_graphs=False):
        self._liveness = liveness
        self._basename = basename
        self._debug = debug
        self._debug_graphs = debug_graphs
        super().__init__(fdata)

    def replace(self, old_instr: Instruction) -> List[Instruction]:
        """Replace Temporary operands with the corresponding allocated
        physical register OR memory location."""
        before: List[Instruction] = []
        after: List[Instruction] = []
        subst: Dict[Operand, Operand] = {}
        # TODO (lab5): compute before,after,args. This is similar to what
        # TODO (lab5): replace_mem and replace_reg from TP04 do.
        # and now return the new list!
        Sr=-1
        
        #before
        for a in old_instr.used():
            if isinstance(a,Temporary):# obligatoire sinon impossible de faire get_alloc
                X = a.get_alloced_loc()
                if isinstance(X,Offset):
                    print("load")
                    before.append( RiscV.ld( GP_REGS[Sr], X ) )
                    subst[a] = GP_REGS[Sr]
                    Sr -= 1
                else:
                    subst[a] = X
        
        #after
        for a in old_instr.defined():
            if isinstance(a,Temporary):# obligatoire sinon impossible de faire get_alloc
                X = a.get_alloced_loc()
                if isinstance(X,Offset):
                    print("write")
                    after.append( RiscV.sd( GP_REGS[Sr], X ) )
                    subst[a] = GP_REGS[Sr]
                    Sr -= 1
                else:
                    subst[a] = X
        
        
        instr = old_instr.substitute(subst)
        return before + [instr] + after

    def prepare(self):
        """Perform all steps related to smart register allocation:

        - Dataflow analysis to compute liveness range of each
          temporary.

        - Interference graph construction

        - Graph coloring

        - Substitution of temporaries by actual locations in the
          3-address code.
        """

        # liveness analysis
        self._liveness.run()

        # conflict graph
        self.build_interference_graph()

        if self._debug_graphs:
            print("printing the conflict graph")
            self._igraph.print_dot(self._basename + "_conflicts.dot")

        # Smart Alloc via graph coloring
        self.smart_alloc(self._basename + "_colored.dot")
        

    def interfere(self, x, y):
        """Interfere function: True if t1 and t2 are in conflit anywhere in
        the function."""
        LV = self._liveness._liveout
        for inst in LV.keys():
            if (x in LV[inst]) and (y in LV[inst]):
                return True
            if (inst.defined() == x) and (y in LV[inst]):
                return True
            if (inst.defined() == y) and (x in LV[inst]):
                return True
                
        return False

    def build_interference_graph(self):
        """Build the interference graph. Nodes of the graph are temporaries,
        and an edge exists between temporaries iff they are in conflict (i.e.
        iff self.interfere(t1, t2)."""
        self._igraph = Graph()
        t = self._fdata._pool.get_all_temps()
        for v in t:
            # print("add vertex "+str(v))
            self._igraph.add_vertex(v)
        tpairs = [(p1, p2) for p1 in t for p2 in t]
        # print(tpairs)
        for (t1, t2) in tpairs:
            if t1 == t2:
                continue  # A temporary cannot conflict with itself
            if self.interfere(t1, t2):
                # print("add edge "+str(t1)+" - "+str(t2))
                self._igraph.add_edge((t1, t2))

    def smart_alloc(self, outputname):
        """Allocate all temporaries with graph coloring
        also prints the colored graph if debug.

        Precondition: the interference graph (_igraph) must have been
        initialized.
        """
        if not self._igraph:
            raise MiniCInternalError("hum, the interference graph seems to be empty")
        # Temporary -> Operand (register or offset) dictionary,
        # specifying where a given Temporary should be allocated:
        alloc_dict = {}
        # TODO (lab5): color the graph and get back the coloring (see
        # Graph.color() in LibGraphes.py). Then, construct a dictionary Temporary ->
        # Register or Offset. Our version is less than 15 lines
        # including debug log. You can get all temporaries with
        # self._function_code._pool.get_all_temps().
        coloringreg = self._igraph.color()
        if self._debug_graphs:
            print("coloring = " + str(coloringreg))
            self._igraph.print_dot(outputname, coloringreg)
        for temp in coloringreg.keys(): # <==>  self._function_code._pool._all_temps
            if(coloringreg[temp]<len(GP_REGS)-3):# on garde les 3 derniers pour aller en mem
                alloc_dict[temp] = GP_REGS[coloringreg[temp]]
            else:
                alloc_dict[temp] = self._fdata.fresh_offset()
        if self._debug:
            print("Allocation:")
            print(alloc_dict)
        self._fdata._pool.set_temp_allocation(alloc_dict)
