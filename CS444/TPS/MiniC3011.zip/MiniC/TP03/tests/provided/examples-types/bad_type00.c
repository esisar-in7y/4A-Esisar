#include "printlib.h"

int main(){
  int x;
  x="blablabla";
  return 0;
}
// EXITCODE 2
// EXPECTED
// In function main: Line 5 col 2: type mismatch for x: integer and string
