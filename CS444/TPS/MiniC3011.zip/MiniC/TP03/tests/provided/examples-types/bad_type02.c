#include "printlib.h"

int main(){
  string x;
  x=1;
  return 0;
}
  
// EXITCODE 2
// EXPECTED
// In function main: Line 5 col 2: type mismatch for x: string and integer
