#include "printlib.h"

int main(){
  int x;
  x=34+f;
  return 0;
}
// EXITCODE 2
// EXPECTED
// In function main: Line 5 col 7: Undefined variable f
