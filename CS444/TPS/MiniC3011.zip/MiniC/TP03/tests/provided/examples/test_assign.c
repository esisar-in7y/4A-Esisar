#include "printlib.h"

int main()
{
  int n,u;
  n=17;
  u=n;
  println_int(n);
  return 0;
}

// EXPECTED
// 17
