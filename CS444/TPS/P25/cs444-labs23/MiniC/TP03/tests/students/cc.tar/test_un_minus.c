#include "printlib.h"

int main(){
    int n,a;
    n = 10;
    a = -n; 
    println_int(a);
    return 0;
}

// EXPECTED
// -10

