#include "printlib.h"

int main(){
    int n;
    bool b;
    string str;
    float f;

    println_int(n);
    println_bool(b);
    println_string(str);
    println_float(f);

    return 0;
}

// EXPECTED
// 0
// 0
// 
// 0.00
