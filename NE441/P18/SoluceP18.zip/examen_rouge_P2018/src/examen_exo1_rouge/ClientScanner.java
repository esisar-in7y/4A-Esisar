package examen_exo1_rouge;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

public class ClientScanner extends Thread {
	
	static Integer port;
	static String ip;
	int p;
	
	static final byte[] bufE = new String("hello").getBytes();
	static final int lenE = bufE.length;
	

	public ClientScanner(int p) {
		this.p = p;
	}
	public ClientScanner(String ip) {
		ClientScanner.ip = ip;
	}

	public static void main(String[] args) {
		ClientScanner ex1 = new ClientScanner("127.0.0.1");
		port = 0;
		System.out.println("Début du scanning des ports UDP de 30000 à 32000 sur la machine \""+ip+"\"");
		ex1.execute(30000,32000);

	}

	private void execute(int pd, int pf) {
		
		for(int i=pd; i<=pf; i++) {
			ClientScanner t = new ClientScanner(i);
			t.start();
		}
		while(port==0) ;
		System.out.println("Le serveur UDP écoute sur le port X = "+port);
		System.out.println("Fin du programme");	
	}

	public void run()
    {
		if (port == 0) try {
			//Creation de la socket
	        DatagramSocket socket = new DatagramSocket();
	
	        // Creation et envoi du message
	        InetSocketAddress adrDest = new InetSocketAddress(ip, p);
	        DatagramPacket dpE = new DatagramPacket(bufE, lenE, adrDest);
	        socket.send(dpE);
	        //System.out.println("Message envoyé: " + ip + "," + p);
	
	        // Attente de la reponse 
	        byte[] bufR = new byte[2048];
	        DatagramPacket dpR = new DatagramPacket(bufR, bufR.length);
	        socket.receive(dpR);
	        String reponse = new String(bufR, dpR.getOffset(), dpR.getLength());
	        //System.out.println("Reponse recue = "+reponse);
	        
	        if(reponse.equals("ok"))
	        {
	        	synchronized(port){
	        		port = p;
	        	}
	        }
	        
	        socket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}
