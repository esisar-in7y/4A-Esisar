package examen_exo2_rouge;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

public class PontTCPTaille {

	public PontTCPTaille() {
	}

	public static void main(String[] args) {
		PontTCPTaille ex2 = new PontTCPTaille();
		try {
			ex2.execute();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Fin du programme");	
	}

	private void execute() throws IOException {
		Socket sokin = new Socket();
		Socket sokout = new Socket();
		sokin.connect(new InetSocketAddress("127.0.0.1", 8000));
		sokout.connect(new InetSocketAddress("127.0.0.1", 8200));
		InputStream is = sokin.getInputStream();
		OutputStream os = sokout.getOutputStream();
		System.out.println("Début de la connexion au serveur 1");
		
        int lenBufR;
        int taille=0;
		byte[] bufR = new byte[1024*1024];
		while((lenBufR = is.read(bufR ))!=-1)
        {
			taille += lenBufR;
			os.write(bufR,0,lenBufR);
        }

		is = sokout.getInputStream();
		while((lenBufR = is.read(bufR))!=-1)
        {
            //String reponse = new String(bufR, 0 , lenBufR );
            //System.out.println("Reponse recue = "+reponse);
        }
		System.out.println("La taille du fichier envoyé par le serveur 1 est : "+taille+" octets");
		
		sokin.close();
		sokout.close();
	}

}
